# Textos con valores reales para la respuesta a los revisores

Datos: 48 grabaciones de referencia (3 narradores × 16 categorías) y 30 salidas raw de XTTS v2
(`2. Output AD`, sin aceleración ni ducking). Descriptores: OpenSMILE 2.6, eGeMAPSv02 Functionals.
La unidad de análisis es el video (n = 10). Seudónimos: Andrea = Woman01, Sergio = Man01, Sebastian = Man02.

> **Limitación crítica.** En `datos` no hay ninguna salida de Spanish-F5. Todo lo que sigue es solo para XTTS v2.
> Para comparar modelos hay que correr las celdas 5–6 del notebook y después la celda 11; el script genera solo
> `tab_alignment_model.tex` y el párrafo de comparación entre modelos.
> Mientras tanto, el artículo **no puede** afirmar diferencias entre XTTS v2 y Spanish-F5.

> **Cifras actuales del artículo.** Los valores 4.06 / 1.87 / 3.68 / 2.37 / 3.52 de la sección Prosody Assignment
> coinciden exactamente con `Analisis_Prosodico_Normalizado.csv`. Ese archivo se calculó sobre los audios
> **sintetizados y procesados** (`Audio Procesado Final`), no sobre las grabaciones humanas. Por eso no describen
> las "estrategias vocales de los narradores": hay que reemplazarlos por los valores de la sección E.

---

## A. Comentarios 1 y 5: Resultados (reemplaza la subsección *Acoustic Prosodic Differentiation*)

```latex
\subsection{Acoustic Prosodic Differentiation}

Table~\ref{tab:tracking} and Fig.~\ref{fig:tracking} compare each XTTS~v2 output with the narrator recording used as its conditioning input. Mean F0 was reproduced closely ($\rho=0.94$, 95\% CI [0.86, 0.97], $p_{\mathrm{Holm}}<0.001$), without systematic bias (median difference $-0.18$~st, $p_{\mathrm{Holm}}=0.79$) and with preserved spread (SD ratio 1.05). F0 range was also tracked ($\rho=0.80$ [0.60, 0.91]), whereas F0 variability was tracked ($\rho=0.68$ [0.41, 0.86]) but systematically reduced (median difference $-0.029$, $p_{\mathrm{Holm}}<0.001$), indicating a flattening of intonation in the synthesized speech. Mean loudness showed a moderate rank correspondence ($\rho=0.50$ [0.15, 0.73], $p_{\mathrm{Holm}}=0.014$) but a large positive offset (median $+0.54$~sone, $p_{\mathrm{Holm}}<0.001$), attributable to the output level of the synthesizer rather than to prosodic transfer. In contrast, the tempo and pause proxies were not related to their conditioning references ($\rho=0.09$ [$-0.32$, 0.46] and $\rho=-0.07$ [$-0.40$, 0.29]; $p_{\mathrm{Holm}}=1.00$): their mean levels matched the references, but their variation across outputs was not explained by the conditioning recording.

Relative to the reference-derived category profiles, the overall deviation was $D=1.02\pm0.25$ (median 1.01, 95\% CI [0.92, 1.09]; normalized scale [1,5]), dominated by loudness ($1.99\pm0.48$), followed by F0 ($0.80\pm0.39$), tempo ($0.65\pm0.58$), and pause ($0.64\pm0.42$) (Table~\ref{tab:sensitivity}). Excluding loudness reduced the overall deviation to $0.70\pm0.29$. Despite this offset, 25 of 30 outputs were closer to their intended category profile than to the 15 non-intended profiles (median video-level specificity $S=0.17$, 95\% CI [0.10, 0.24]; Wilcoxon $p=0.002$, $r_{rb}=1.00$, $n=10$ videos; Fig.~\ref{fig:specificity}). The result held under gain-invariant normalization ($z$-scores computed within each source: 21 of 30 outputs with $S>0$, median $S=0.16$ [0.03, 0.26], $p=0.020$). Descriptive results by intended category are reported in Table~\ref{tab:alignment_category}.
```

## B. Comentarios 1 y 5: reemplaza *Correspondence with Reference-Derived Profiles*

```latex
\subsection{Correspondence with Reference-Derived Profiles}

The narrator reference did not have a significant effect on overall deviation from the category profiles (Friedman $\chi^2(2)=3.20$, $p_{\mathrm{Holm}}=0.40$, Kendall's $W=0.16$, 10 videos; Table~\ref{tab:alignment_narrator}). At the feature level, the narrator reference affected loudness deviation ($\chi^2(2)=14.6$, $p_{\mathrm{Holm}}=0.003$, $W=0.73$; Woman01 $1.49\pm0.26$, Man01 $2.40\pm0.33$, Man02 $2.08\pm0.32$), and showed a trend for F0 ($\chi^2(2)=8.6$, $p_{\mathrm{Holm}}=0.054$, $W=0.43$), but not tempo ($p_{\mathrm{Holm}}=0.50$) or pause ($p_{\mathrm{Holm}}=0.25$). Deviation from the narrator's own conditioning recording ($D^{\mathrm{nar}}$) differed across narrators ($\chi^2(2)=7.8$, $p=0.020$, $W=0.39$), being lowest for Woman01 ($0.71\pm0.21$) and highest for Man01 ($1.04\pm0.29$); no pairwise comparison survived Holm correction. A linear mixed-effects model with video as a random intercept yielded a consistent pattern (Woman01 vs.\ Man01: $\beta=-0.22$, 95\% CI [$-0.38$, $-0.05$]).

In the reference corpus, all four descriptors varied across the 16 intended categories (Friedman with narrators as blocks: F0 $W=0.67$, loudness $W=0.75$, tempo $W=0.63$, pause $W=0.78$; all $p_{\mathrm{Holm}}\le0.023$). However, inter-narrator agreement on the category profiles was limited (Table~\ref{tab:reference_icc}): ICC(2,$k$) was 0.38 [0.11, 0.51] for F0, 0.60 [0.27, 0.75] for loudness, 0.52 [0.09, 0.74] for tempo, and 0.82 [0.47, 0.94] for pause. The three narrators therefore realized the same intended categories with partly different acoustic strategies, and the averaged target profiles should be interpreted as corpus-specific references. Because neither the narrator renditions nor the scene-category assignments were perceptually validated, these results are interpreted as acoustic correspondence with intended conditioning profiles rather than confirmation of perceived emotion.
```

## C. Comentario 3: oración del Related Work / Sección 4.5

Hay que añadir esta frase después del párrafo de eGeMAPS (Cambio 3 de la respuesta anterior):

```latex
As a complementary check, two contour-related descriptors, F0 variability (\texttt{F0semitoneFrom27.5Hz\_sma3nz\_stddevNorm}) and F0 range (\texttt{pctlrange0-2}), were also extracted and are reported in Table~\ref{tab:tracking} and Table~\ref{tab:reference_icc}.
```

## D. Discusión: reemplaza la oración rota y la del 2.º párrafo

```latex
The reference-tracking analysis shows that XTTS~v2 transferred the level and range of fundamental frequency from the conditioning recording, but compressed F0 variability and did not transfer the temporal descriptors: the tempo and pause proxies of the outputs were unrelated to those of their references. In this zero-shot cloning setting, timing therefore appears to be governed mainly by the input text and the synthesis model rather than by the reference recording. Category-specific correspondence was nonetheless observed for most outputs, but the effect was modest and, given that only six categories and ten videos were evaluated, should be regarded as preliminary.
```

Limitación nueva:

```latex
Fifth, loudness comparisons between studio recordings and synthesized outputs are confounded by differences in output gain; the gain-invariant analysis (Table~\ref{tab:sensitivity}) should therefore be preferred for this descriptor, and future work should apply loudness normalization (e.g., EBU~R128) before feature extraction.
```

## E. Reemplazo de 4.06 / 1.87 / 3.68 / 2.37 / 3.52 (corpus humano, unidades crudas)

```latex
Inter-narrator variability in the reference corpus reflected distinct vocal strategies: Woman01 showed the highest mean F0 ($31.0\pm2.9$~st across the 16 categories), Man01 the highest loudness ($0.47\pm0.09$~sone) and the slowest tempo ($2.25\pm0.34$ voiced segments/s), and Man02 the lowest loudness ($0.30\pm0.09$~sone). Woman01 and Man02 showed similar tempo ($2.75\pm0.36$ and $2.77\pm0.25$ segments/s).
```

## F. Pies de figura

- `fig_reference_tracking`: *Reference-to-output tracking for XTTS v2. Each point is one synthesized output plotted against the narrator recording used as its conditioning input; the dashed line marks identity. ρ: Spearman correlation (n = 30).*
- `fig_reference_profiles`: *Raw acoustic descriptors of the 16 intended categories in the reference corpus. Symbols: individual narrators; black tick: mean; gray bar: ±1 SD across narrators.*
- `fig_specificity`: *Deviation of each output from its intended category profile (x) versus its mean deviation from the 15 non-intended profiles (y). Points above the identity line are closer to their intended profile.*
- `fig_deviation_by_narrator`: *Absolute deviation from the intended category profile by narrator reference and feature (normalized scale). Boxes: median and IQR; points: individual outputs.*
- `fig_radar_reference_emotions` (reemplaza `EmocionesBase`/resumen): *Mean normalized profiles of the reference corpus (three narrators) for the high- and low-intensity variant of each primary emotion. T: mean F0; I: loudness; R: voiced segments/s; D: mean unvoiced length; pooled min–max scale [1,5]. Radar plots are illustrative; numerical values and tests are reported in Tables X–Y.*
- `fig_radar_reference_Woman01/Man01/Man02` (reemplazan `EmocionesLocutores`): *Per-narrator profiles; dashed gray: group mean of the high-intensity variant.*
- `fig_radar_videos_xtts` (reemplaza `Modelos_Evaluacion`): *Normalized profiles of the XTTS v2 outputs per video and narrator reference; dashed black: reference-derived target profile of the intended category.*
