# Cómo añadir Spanish-F5 al análisis

En `EmotiveAD` no hay ningún audio de Spanish-F5: `reportes/acustica/model_comparison_status.json`
dice `"pending"`. Por eso los resultados actuales cubren solo XTTS v2. Sirven como resultados
preliminares, pero el artículo no puede comparar modelos hasta que existan los 30 WAV de F5.

El análisis ya está listo para dos modelos. En cuanto el manifiesto contenga `xtts` y `spanish_f5`,
genera automáticamente:

- **Tablas:** `tab_alignment_model.tex` (Wilcoxon pareado por video, Holm, $r_{rb}$, IC), `tab_reference_tracking.tex` con las filas de ambos modelos y la prueba de diferencia de ρ, y `tab_sensitivity.tex` con una columna por modelo.
- **Figuras:** `fig_deviation_by_model`, `fig_deviation_by_narrator` (dividida por modelo), `fig_reference_tracking` (color por modelo, forma por narrador), `fig_specificity`, `fig_radar_videos_xtts` y `fig_radar_videos_spanish_f5`.
- **Texto:** el párrafo de comparación entre modelos en `RESULTADOS_MANUSCRITO.md`, redactado según la significancia.

## Ruta recomendada: Colab con GPU y ambos modelos

Así los dos motores usan exactamente el mismo texto revisado, la misma versión y las mismas referencias. Es lo que exige una comparación justa.

1. Sube a `Mi unidad/EmotiveAD/V01 Original` el archivo `revision_analysis.py`, la carpeta `fonts` y el notebook `AD_Existente_XTTS_SpanishF5_Colab_revision.ipynb`.
2. Activa la GPU y ejecuta las celdas 1–6. La celda 6 usa `--option 3` y genera 60 WAV.
3. Ejecuta las celdas 10–14. La celda 10 se detiene si falta alguno de los dos motores.
4. Descarga el zip (celda 15). Las cifras nuevas reemplazan a las de este paquete, incluidas las de XTTS, porque XTTS también se regenera.

## Ruta alternativa: solo F5 en tu computadora

Ya tienes `.engines/spanish_f5` y `.engines/env.json`. Desde `V01 Original`:

```powershell
python run_pipeline.py --root datos --output outputs_f5 --option 2 --env .engines\env.json
python revision_analysis.py --manifest outputs_f5\audio_manifest.json manifest_xtts_historico.json `
  --references datos\Locutores --narrators Andrea Sergio Sebastian `
  --pseudonyms Andrea=Woman01 Sergio=Man01 Sebastian=Man02 --output revision_estadistica
```

`manifest_xtts_historico.json` viene en este zip. Cópialo a `V01 Original`; sus rutas son relativas a esa carpeta.

**Advertencias:**

- **Rendimiento:** F5 en CPU es lento. Sin GPU NVIDIA puede tardar varios minutos por audio.
- **Texto:** sin `--projects`, el pipeline importa el `main_summary` histórico. Ese es el texto que debería haber usado XTTS histórico, pero no está verificado. `prepare_existing_ad.py` limpió notas o marcas en 7 de los 10 textos. Si algún WAV histórico de XTTS lee esas notas, la comparación no es justa. Por eso la ruta recomendada es regenerar ambos motores.
- **Transcripción de la referencia:** F5 necesita el texto exacto de cada grabación de referencia. Sin un `.txt` junto al WAV, usa su transcriptor local. Revísalo antes de fijar el experimento.
