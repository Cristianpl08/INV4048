# Resultados para el manuscrito (generado automáticamente)

Salidas analizadas: 30 | videos: 10 | categorías usadas: 6 | categorías completas en el corpus de referencia: 16

Revise cada frase antes de pegarla. La redacción cambia automáticamente según la significancia.

## Efecto del narrador

The narrator reference did not have a significant effect on overall deviation (Friedman $\chi^2(2)=3.20$, $p_{\mathrm{Holm}}=0.404$, Kendall's $W=0.16$, 10 videos).

## Especificidad de categoría

25 of 30 XTTS v2 outputs were closer to their intended category profile than to the non-intended profiles (median video-level $S=0.17$, 95\% CI [0.10, 0.24], $p_{\mathrm{Holm}}=0.002$).

## Consistencia entre narradores (corpus de referencia)

Inter-narrator consistency across the 16 categories was F0 (T): ICC(2,$k$)$=0.38$ [0.11, 0.51]; Loudness (I): ICC(2,$k$)$=0.60$ [0.27, 0.75]; Tempo (R): ICC(2,$k$)$=0.52$ [0.09, 0.74]; Pause (D): ICC(2,$k$)$=0.82$ [0.47, 0.94].

Guía de interpretación (Koo & Li, 2016): <0.50 pobre, 0.50–0.75 moderada, 0.75–0.90 buena, >0.90 excelente.

## ¿Varían los descriptores entre categorías en el corpus humano?

Friedman across categories, narrators as blocks: F0 (T) ($\chi^2(15)=30.1$, $p_{\mathrm{Holm}}=0.023$, $W=0.67$); Loudness (I) ($\chi^2(15)=33.7$, $p_{\mathrm{Holm}}=0.011$, $W=0.75$); Tempo (R) ($\chi^2(15)=28.4$, $p_{\mathrm{Holm}}=0.023$, $W=0.63$); Pause (D) ($\chi^2(15)=34.9$, $p_{\mathrm{Holm}}=0.010$, $W=0.78$). Con solo 3 bloques la potencia es baja; reporte W como tamaño de efecto.

## Perfiles por narrador (reemplaza 4.06, 1.87, 3.68, 2.37, 3.52)

| Narrador | F0 (T) | Loudness (I) | Tempo (R) | Pause (D) |
|---|---|---|---|---|
| Man01 | 2.07 ± 0.73 | 2.20 ± 0.35 | 2.94 ± 0.58 | 2.73 ± 1.19 |
| Man02 | 2.51 ± 0.90 | 1.58 ± 0.33 | 3.83 ± 0.42 | 2.60 ± 0.83 |
| Woman01 | 3.88 ± 0.77 | 1.90 ± 0.22 | 3.81 ± 0.61 | 2.31 ± 0.87 |

## Categorías

Solo descriptivo. Categorías con 1 video: reportar rango, no IC.

| label                  | engine   |   n_videos |   n_outputs |   median |   min |   max |   S_mean |
|:-----------------------|:---------|-----------:|------------:|---------:|------:|------:|---------:|
| Trust/Acceptance       | xtts     |          4 |          12 |    1.007 | 0.682 | 1.321 |    0.2   |
| Joy/Ecstasy            | xtts     |          2 |           6 |    1.103 | 0.697 | 1.755 |    0.226 |
| Joy/Serenity           | xtts     |          1 |           3 |    0.968 | 0.779 | 1.023 |    0.172 |
| Trust/Admiration       | xtts     |          1 |           3 |    0.995 | 0.714 | 1.257 |    0.114 |
| Anticipation/Interest  | xtts     |          1 |           3 |    1.108 | 0.624 | 1.16  |    0.16  |
| Anticipation/Vigilance | xtts     |          1 |           3 |    1.068 | 0.969 | 1.266 |    0.092 |


Modelo mixto: ver mixed_model.txt.

## Seguimiento referencia → salida (cada salida vs. SU grabación condicionante)

**XTTS v2**
- Mean F0: ρ = 0.94 [0.86, 0.97], p_Holm <0.001; sesgo mediano = -0.184 (p_Holm =0.792); razón de DE = 1.05
- Mean loudness: ρ = 0.50 [0.15, 0.73], p_Holm =0.014; sesgo mediano = 0.539 (p_Holm <0.001); razón de DE = 1.55
- Voiced segments/s: ρ = 0.09 [-0.32, 0.46], p_Holm =1.000; sesgo mediano = 0.016 (p_Holm =1.000); razón de DE = 1.60
- Mean unvoiced length: ρ = -0.07 [-0.40, 0.29], p_Holm =1.000; sesgo mediano = -0.007 (p_Holm =1.000); razón de DE = 1.40
- F0 variability (CV): ρ = 0.68 [0.41, 0.86], p_Holm <0.001; sesgo mediano = -0.029 (p_Holm <0.001); razón de DE = 1.19
- F0 range (20--80 pct.): ρ = 0.80 [0.60, 0.91], p_Holm <0.001; sesgo mediano = -0.447 (p_Holm =0.792); razón de DE = 0.72

## Sensibilidad a la normalización

**XTTS v2**
- Overall D (pooled min-max): 1.02 ± 0.25; mediana 1.01 [0.92, 1.09]
- D without loudness: 0.70 ± 0.29; mediana 0.68 [0.56, 0.72]
- D, z-score within source (gain-invariant): 0.85 ± 0.42; mediana 0.77 [0.59, 0.94]
- z within source, without loudness: 0.84 ± 0.48; mediana 0.67 [0.55, 0.83]
- Specificity S (pooled min-max): 0.18 ± 0.19; mediana 0.16 [0.12, 0.28]; 25/30 > 0, Wilcoxon p =0.002
- Specificity S (z within source): 0.12 ± 0.26; mediana 0.16 [0.03, 0.26]; 21/30 > 0, Wilcoxon p =0.020

